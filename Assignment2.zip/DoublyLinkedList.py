# ===============================================================
# Name: Jude Vargas
# Date: 10/27/2023
# Algorithm: N/A
# References: N/A
# ===============================================================

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.previous = None

    def __str__(self):
        return str(self.data)

class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.length = 0
    
    def __str__(self):
        result = []
        for i in self:
            result.append(str(i))
        return str(result)
    
    def is_empty(self):
        """
        Function is_empty returns True if the doubly-linked list is empty, else False
        Parameters: None
        Returns: True if the doubly-linked list is empty, else False
        """
        # The list is empty if the head doesn't point to anything
        return self.head is None
    
    def size(self):
        """
        Function size returns an int representing the length of the doubly-linked list
        Parameters: None
        Returns: an int representing the length of the doubly-linked list
        """
        return self.length
    
    def add(self, item):
        """
        Function add adds the specified item (as a node) to the beginning (head) of the doubly-linked list
        Parameters:
            item: the item to add to the doubly-linked list
        Returns: None
        """
        # Create new node using item as its data
        new_node = Node(item)

        # If the list already has items in it, update the pointers between the current head and this node
        if not self.is_empty():
            new_node.next = self.head
            self.head.previous = new_node
        # If the list is empty, just set the tail to this node since it'll be both the head and the tail
        else:
            self.tail = new_node
        # Finally, set the new node as the new head (regardless of whether the list is empty or not)
        self.head = new_node

        # Update list length
        self.length += 1

    def __iter__(self):
        """
        Function __iter__ allows the doubly-linked list to be iterated over by something like a for loop
        Parameters: None
        Returns: None (yields each item in the doubly-linked list for iterators)
        """
        # Run through the entire list, yielding each item for external iterators
        current = self.head
        while current is not None:
            yield current
            current = current.next

    def append(self, item):
        """
        Function append adds the specified item (as a node) to the end (tail) of the doubly-linked list
        Parameters:
            item: the item to append to the doubly-linked list
        Returns: None
        """
        # Create new node using item as its data
        new_node = Node(item)

        # If the list already has items in it, update the pointers between the current tail and this node
        if not self.is_empty():
            new_node.previous = self.tail
            self.tail.next = new_node
        # If the list is empty, just set the head to this node since it'll be both the head and the tail
        else:
            self.head = new_node
        # Finally, set the new node as the new tail (regardless of whether the list is empty or not)
        self.tail = new_node

        # Update list length
        self.length += 1
    
    def pop(self, pos = None):
        """
        Function pop removes the item at the specified position (or the last position if pos = None)
        Parameters:
            pos (optional) = an int representing the position (index) of the item to remove
        Returns: the item that has been removed from the doubly-linked list (or None if no item was removed)
        """
        # Since it's faster to start searching from the tail if the item is in the second half, we do so
        search_second_half = False
        if pos is not None:
            # The middle item in a list with an odd amount of items will be searched from the tail end as well
            search_second_half = self.length // 2 < pos

        # Start from the tail end if searching the second half, otherwise start from the head
        if search_second_half:
            previous, current = self.tail, self.tail
        else:
            previous, current = self.head, self.head

        # Make sure the index (if one is given) is valid
        if self.is_empty() or (pos is not None and pos >= self.length):
            return None
        elif pos is not None and pos < 0:
            return None
        elif pos is not None and not isinstance(pos, int):
            return None
        
        # If there's only one item in the list, just reset the list basically
        if self.length == 1:
            self.head = None
            self.tail = None
        # Handle cases where an index is given
        elif pos is not None:
            # If removing the very first item, just set the next item as the new head
            if pos == 0:
                current.next.previous = None
                self.head = current.next
            else:
                # Since a numerical index is given, count up/down from one of the ends until the position is reached
                count = self.length if search_second_half else 0
                while count != pos:
                    # If searching from the tail end, go backwards until the item is found
                    if search_second_half:
                        current = previous
                        previous = previous.previous
                        count -= 1
                    # Otherwise, search from the head (go forwards)
                    else:
                        previous = current
                        current = current.next
                        count += 1
                # If there's an item in the list after the current one, update its previous pointer
                if current.next is not None:
                    current.next.previous = previous
                # Update the previous item's next pointer (even if it's None)
                previous.next = current.next
        # Handle cases where an index is NOT given (remove the last item)
        else:
            # Set current to the item being removed so it gets returned correctly
            current = self.tail

            self.tail = self.tail.previous
            self.tail.next = None

        # Update list length and return the item that was removed
        self.length -= 1
        return current

    def search(self, item):
        """
        Function search returns True if the specified item is found within the doubly-linked list, else False
        Parameters:
            item: the specified item to search for within the doubly-linked list
        Returns: True if the specified item is found within the doubly-linked list, else False
        """
        # If the list is empty, it obviously can't have whatever item is being searched
        if self.is_empty():
            return False
        
        # If it's not empty, just search through the list and return True if the item is found, else False
        current = self.head
        while current is not None:
            if current.data == item:
                return True
            else:
                current = current.next
        return False

    def remove(self, item):
        """
        Function remove removes the specified item from the doubly-linked list (if it is found within the list)
        Parameters:
            item: the specified item to remove from the doubly-linked list
        Returns: None
        """
        # Search through the list, keeping track of the current AND previous item
        previous, current = self.head, self.head

        # Handle the case where the list is empty
        if self.is_empty():
            raise ValueError("Error: List is already empty")
        
        # If the list is NOT empty, search through from the head
        while current is not None:
            # If the item to remove is found:
            if current.data == item:
                # If the item is the list's head, just set the head to the next item in the list
                if current == self.head:
                    self.head = current.next
                    self.head.previous = None
                # If it's the tail, set the tail to the previous item in the list
                elif current == self.tail:
                    self.tail = previous
                    self.tail.next = None
                # If it's neither the head nor the tail, update the pointers for the items on either side of current
                else:
                    previous.next = current.next
                    current.next.previous = previous
                # Update list length
                self.length -= 1
                return
            # Move forward through the list if the item hasn't been found yet
            else:
                previous = current
                current = current.next
        # Throw an error if the item doesn't exist within the list
        raise ValueError("Error: Item could not be found within the list")