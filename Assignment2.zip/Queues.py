# ===============================================================
# Name: Jude Vargas
# Date: 11/01/2023
# Algorithm: N/A
# References: Noah Mattison
# ===============================================================

from LinkedList import *
from DoublyLinkedList import *

class QueuePythonList:
    def __init__(self):
        self.list = []

    def size(self):
        """
        Function size returns the length (size) of the queue
        Parameters: None
        Returns: the length (size) of the queue
        """
        return len(self.list)
    
    def is_empty(self):
        """
        Function is_empty returns True if this queue has no items in it, else False
        Parameters: None
        Returns: True if this queue has no items in it, else False
        """
        return self.size() == 0

    def enqueue(self, item):
        """
        Function enqueue adds a given item to the rear of the queue
        Parameters:
            item: the item to add to the rear of the queue
        Returns: None
        """
        self.list.insert(0, item)

    def dequeue(self):
        """
        Function dequeue removes and returns the item at the front of the queue
        Parameters: None
        Returns: the item at the front of the queue (which is now removed)
        """
        if not self.is_empty():
            return self.list.pop()

class QueueLinkedList:
    def __init__(self):
        self.list = LinkedList()

    def size(self):
        """
        Function size returns the length (size) of the queue
        Parameters: None
        Returns: the length (size) of the queue
        """
        return self.list.size()
    
    def is_empty(self):
        """
        Function is_empty returns True if this queue has no items in it, else False
        Parameters: None
        Returns: True if this queue has no items in it, else False
        """
        return self.list.is_empty()

    def enqueue(self, item):
        """
        Function enqueue adds a given item to the rear of the queue
        Parameters:
            item: the item to add to the rear of the queue
        Returns: None
        """
        self.list.append(item)

    def dequeue(self):
        """
        Function dequeue removes and returns the item at the front of the queue
        Parameters: None
        Returns: the item at the front of the queue (which is now removed)
        """
        if not self.is_empty():
            return self.list.pop(0)

class QueueDoublyLinkedList:
    def __init__(self):
        self.list = DoublyLinkedList()

    def size(self):
        """
        Function size returns the length (size) of the queue
        Parameters: None
        Returns: the length (size) of the queue
        """
        return self.list.size()
    
    def is_empty(self):
        """
        Function is_empty returns True if this queue has no items in it, else False
        Parameters: None
        Returns: True if this queue has no items in it, else False
        """
        return self.list.is_empty()

    def enqueue(self, item):
        """
        Function enqueue adds a given item to the rear of the queue
        Parameters:
            item: the item to add to the rear of the queue
        Returns: None
        """
        self.list.append(item)

    def dequeue(self):
        """
        Function dequeue removes and returns the item at the front of the queue
        Parameters: None
        Returns: the item at the front of the queue (which is now removed)
        """
        if not self.is_empty():
            return self.list.pop(0)

class CircularlyLinkedList:
    def __init__(self) -> None:
        pass